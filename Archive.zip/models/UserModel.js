const Sequelize = require('sequelize');
const {DataTypes} = Sequelize;

// const User = db.define('users',{
//     name: DataTypes.STRING,
//     email: DataTypes.STRING,
//     password: DataTypes.STRING,
// },{
//     freezeTableName:true
// });

// module.exports = User;

// (async()=>{
//     await db.sync();
// })();